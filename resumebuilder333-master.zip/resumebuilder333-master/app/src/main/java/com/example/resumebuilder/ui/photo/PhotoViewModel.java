package com.example.resumebuilder.ui.photo;

import androidx.lifecycle.ViewModel;

public class PhotoViewModel extends ViewModel {
}
