package com.example.resumebuilder.ui.resume;

import androidx.lifecycle.ViewModel;

public class ResumeViewModel extends ViewModel {

}
